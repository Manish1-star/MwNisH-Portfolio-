# Assets

## images/
Place your images here:
- `profile.jpg` or `profile.webp` — your profile photo (recommended: 400x400px)
- `preview.png` — screenshot of your site for the README
- Any project screenshots

## icons/
Place any custom SVG icons here.
Using Remix Icons CDN (already linked in HTML) so no download needed for icons.
